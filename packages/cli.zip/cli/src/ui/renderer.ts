import chalk from "chalk";
import ora, { type Ora } from "ora";
import type { PipelineEvent } from "@foundation-cli/core";

const SEP_FULL = chalk.dim("━".repeat(52));
const SEP_THIN = chalk.dim("─".repeat(52));

export function printBanner(): void {
  process.stdout.write("\n");
  process.stdout.write(SEP_FULL + "\n");
  process.stdout.write(
    chalk.bold.white("  🚀  FOUNDATION CLI") + "\n",
  );
  process.stdout.write(
    chalk.dim("  Build your app architecture in minutes") + "\n",
  );
  process.stdout.write(SEP_FULL + "\n\n");
}

export function printSection(title: string): void {
  process.stdout.write(`\n${chalk.bold.cyan(`  ${title}`)}\n`);
  process.stdout.write(SEP_THIN + "\n");
}

export function printRow(label: string, value: string): void {
  const isNone = value === "none" || value === "None";
  const displayValue = isNone
    ? chalk.dim("None")
    : chalk.green(value);
  process.stdout.write(
    `  ${chalk.dim((label + ":").padEnd(18))} ${displayValue}\n`,
  );
}

export function printSuccess(projectName: string): void {
  process.stdout.write(`\n${SEP_FULL}\n`);
  process.stdout.write(chalk.bold.green("  🎉  Project created successfully!\n"));
  process.stdout.write(`${SEP_FULL}\n\n`);
  process.stdout.write(`  ${chalk.bold("Next steps:")}\n\n`);
  process.stdout.write(`  ${chalk.cyan("cd")} ${chalk.yellow(projectName)}\n`);
  process.stdout.write(`  ${chalk.cyan("npm install")}\n`);
  process.stdout.write(`  ${chalk.cyan("npm run dev")}\n`);
  process.stdout.write(`\n${SEP_FULL}\n\n`);
}

export function printError(message: string): void {
  process.stderr.write(
    `\n  ${chalk.bold.red("✖ Error:")} ${chalk.red(message)}\n\n`,
  );
}

export function printAbort(): void {
  process.stdout.write(chalk.yellow("\n  Aborted. No files were written.\n\n"));
}

/**
 * Creates a managed Ora spinner that updates based on pipeline progress events.
 * Returns a function that accepts PipelineEvents and drives the spinner.
 */
export function createPipelineRenderer(): {
  handler: (event: PipelineEvent) => void;
  spinner: Ora;
  stop: () => void;
} {
  const spinner = ora({ color: "cyan", spinner: "dots" }).start(
    chalk.dim("Initialising…"),
  );

  const STAGE_LABELS: Record<string, string> = {
    "before-write":   "Running pre-write hooks",
    "write-files":    "Writing project files",
    "apply-patches":  "Applying config patches",
    "before-install": "Running pre-install hooks",
    "install-deps":   "Installing dependencies",
    "after-install":  "Running post-install hooks",
    "after-write":    "Running post-write hooks",
    "complete":       "Done",
  };

  const handler = (event: PipelineEvent): void => {
    const stageLabel = STAGE_LABELS[event.stage] ?? event.stage;

    if (event.stage === "complete") {
      spinner.succeed(chalk.green("Pipeline complete"));
      return;
    }

    if (event.message.toLowerCase().includes("fail")) {
      spinner.fail(chalk.red(`${stageLabel}: ${event.message}`));
      return;
    }

    spinner.text = chalk.dim(`${stageLabel}… ${event.message}`);
  };

  const stop = (): void => {
    if (spinner.isSpinning) spinner.stop();
  };

  return { handler, spinner, stop };
}

export function printSummaryTable(
  rows: ReadonlyArray<{ label: string; value: string }>,
): void {
  process.stdout.write("\n");
  for (const row of rows) {
    printRow(row.label, row.value);
  }
  process.stdout.write("\n");
}