import path from "node:path";
import chalk from "chalk";
import {
  ModuleRegistry,
  resolveModules,
  buildCompositionPlan,
  runExecutionPipeline,
  renderAllTemplates,
  type PipelineEvent,
} from "@foundation-cli/core";
import { loadBuiltinModules, selectionsToModuleIds } from "@foundation-cli/modules";
import { runPromptFlow } from "../prompt/flow.js";
import {
  createPipelineRenderer,
  printSuccess,
  printError,
  printSection,
  printRow,
} from "../ui/renderer.js";

export async function runCreateCommand(): Promise<void> {
  // ── 1. Collect user selections ────────────────────────────────────────────
  const selection = await runPromptFlow();

  // ── 2. Build registry ─────────────────────────────────────────────────────
  const registry = new ModuleRegistry();
  loadBuiltinModules(registry);

  // ── 3. Resolve module IDs from selection values ───────────────────────────
  const selectionValues = Object.values(selection.rawSelections);
  const moduleIds = selectionsToModuleIds(selectionValues, registry);

  // ── 4. Resolve dependencies + build composition plan ─────────────────────
  let plan;
  try {
    if (moduleIds.length === 0) {
      plan = {
        files: [],
        dependencies: [],
        configPatches: [],
        orderedModules: [],
      };
    } else {
      const resolution = resolveModules(moduleIds, registry);
      plan = buildCompositionPlan(resolution.ordered);

      if (resolution.added.length > 0) {
        process.stdout.write(
          `\n  ${chalk.dim("Auto-added:")} ${chalk.yellow(resolution.added.join(", "))}\n`,
        );
      }
    }
  } catch (err) {
    printError(err instanceof Error ? err.message : String(err));
    process.exit(1);
  }

  // ── 5. Show what will be generated ───────────────────────────────────────
  printSection("Generating Project");
  printRow("Modules", String(plan.orderedModules.length));
  printRow("Files", String(plan.files.length));
  printRow("Packages", String(plan.dependencies.length));
  process.stdout.write("\n");

  // ── 6. Run execution pipeline ─────────────────────────────────────────────
  const { handler, stop } = createPipelineRenderer();
  const targetDir = path.resolve(process.cwd(), selection.projectName);

  const templateVars: Record<string, unknown> = {
    projectName: selection.projectName,
    projectType: selection.projectType,
    ...selection.rawSelections,
  };

  // Render EJS template variables (e.g. <%= projectName %>) into every
  // file template AND into configPatch merge values so that strings like
  // "docker build -t <%= projectName %> ." are expanded before being written.
  const renderedPlan = {
    ...plan,
    files: renderAllTemplates(
      plan.files.map((f) => ({ relativePath: f.relativePath, content: f.content })),
      templateVars as Record<string, string>,
    ).map((f) => ({ relativePath: f.relativePath, content: f.content })),
    configPatches: plan.configPatches.map((patch) => ({
      ...patch,
      merge: renderTemplateValues(patch.merge as Record<string, unknown>, templateVars as Record<string, string>),
    })),
  };

  try {
    await runExecutionPipeline(renderedPlan, {
      targetDir,
      registry,
      // Always skip running npm/pnpm install during scaffold — the pipeline
      // now writes deps to package.json unconditionally regardless of this flag.
      // Users run `npm install` themselves after reviewing the generated project.
      skipInstall: true,
      dryRun: false,
      hookContext: {
        config: templateVars,
        selectedModules: moduleIds,
      },
      // ── Phase 3: persist project state after successful commit ────────────
      stateOptions: {
        projectName: selection.projectName,
        selections: selection.rawSelections as unknown as Record<string, string>,
      },
      onProgress: (event: PipelineEvent) => handler(event),
    });
  } catch (err) {
    stop();
    printError(err instanceof Error ? err.message : String(err));
    process.exit(1);
  }

  stop();

  await writeBaseFiles(targetDir, selection.projectName, selection.rawSelections);

  printSuccess(selection.projectName);
}

// ── Base files (always written regardless of module selection) ─────────────

async function writeBaseFiles(
  targetDir: string,
  projectName: string,
  selections: UserRawSelections,
): Promise<void> {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");

  const write = async (rel: string, content: string): Promise<void> => {
    const abs = path.default.join(targetDir, rel);
    try {
      await fs.default.access(abs);
    } catch {
      await fs.default.mkdir(path.default.dirname(abs), { recursive: true });
      await fs.default.writeFile(abs, content, "utf-8");
    }
  };

  await write(
    "package.json",
    JSON.stringify(
      {
        name: projectName,
        version: "0.1.0",
        private: true,
        type: "module",
        scripts: {
          dev: "echo 'Configure dev script'",
          build: "echo 'Configure build script'",
          start: "echo 'Configure start script'",
          lint: "eslint .",
        },
      },
      null,
      2,
    ),
  );

  await write("README.md", buildReadme(projectName, selections));
  await write(".gitignore", BASE_GITIGNORE);
  await write(
    ".eslintrc.json",
    JSON.stringify(
      {
        root: true,
        env: { node: true, es2022: true },
        extends: ["eslint:recommended"],
        parserOptions: { ecmaVersion: 2022, sourceType: "module" },
        rules: { "no-unused-vars": "warn", "no-console": "off" },
      },
      null,
      2,
    ),
  );
}

type UserRawSelections = {
  frontend: string;
  backend: string;
  database: string;
  auth: string;
  ui: string;
  stateManagement: string;
  deployment: string;
};

function buildReadme(projectName: string, s: UserRawSelections): string {
  const stack = [
    s.frontend !== "none" && `- **Frontend:** ${s.frontend}`,
    s.backend !== "none" && `- **Backend:** ${s.backend}`,
    s.database !== "none" && `- **Database:** ${s.database}`,
    s.auth !== "none" && `- **Auth:** ${s.auth}`,
    s.ui !== "none" && `- **UI:** ${s.ui}`,
    s.deployment !== "none" && `- **Deployment:** ${s.deployment}`,
  ]
    .filter(Boolean)
    .join("\n");

  return `# ${projectName}

> Generated by [Foundation CLI](https://github.com/foundation-cli)

## Stack

${stack || "- Custom configuration"}

## Getting Started

\`\`\`bash
cd ${projectName}
npm install
npm run dev
\`\`\`

## Environment Variables

Copy \`.env.example\` to \`.env\` and fill in your values:

\`\`\`bash
cp .env.example .env
\`\`\`

## Project Structure

\`\`\`
src/
├── server.ts        # Entry point
├── auth/            # Authentication
├── db/              # Database client
└── styles/          # CSS / Tailwind
\`\`\`
`;
}

const BASE_GITIGNORE = `# Dependencies
node_modules/
.pnp
.pnp.js

# Build
dist/
build/
.next/
out/

# Env
.env
.env.local
.env.*.local

# Logs
*.log
npm-debug.log*

# OS
.DS_Store
Thumbs.db

# Editor
.vscode/
.idea/
`;
// ── Template value renderer ────────────────────────────────────────────────────

/**
 * Recursively walks a configPatch `merge` object and renders any string values
 * that contain EJS-style `<%= varName %>` tokens using the provided variables.
 *
 * This ensures that patches like `{ scripts: { "docker:build": "docker build -t <%= projectName %> ." } }`
 * are correctly expanded before being written to disk.
 */
function renderTemplateValues(
  obj: Record<string, unknown>,
  vars: Record<string, string>,
): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === "string") {
      result[key] = value.replace(/<%=\s*(\w+)\s*%>/g, (_, name: string) => vars[name] ?? _);
    } else if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      result[key] = renderTemplateValues(value as Record<string, unknown>, vars);
    } else {
      result[key] = value;
    }
  }
  return result;
}